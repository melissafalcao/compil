package br.ufpe.cin.if688.parsing.analysis;

public abstract class GeneralSymbol {

	@Override
	public abstract boolean equals(Object obj);

}
