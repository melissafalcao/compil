package br.ufpe.cin.if688.parsing.grammar;

public final class Terminal extends Symbol {
   
    public Terminal(String name) {
        super(name, true);
    }
}