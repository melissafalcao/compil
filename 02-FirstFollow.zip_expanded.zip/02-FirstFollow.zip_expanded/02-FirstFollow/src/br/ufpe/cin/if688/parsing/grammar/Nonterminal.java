package br.ufpe.cin.if688.parsing.grammar;

public final class Nonterminal extends Symbol {
   
    public Nonterminal(String name) {
        super(name, false);
    }
}