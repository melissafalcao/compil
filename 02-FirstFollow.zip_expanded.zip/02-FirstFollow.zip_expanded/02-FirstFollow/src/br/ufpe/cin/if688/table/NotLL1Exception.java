package br.ufpe.cin.if688.table;

@SuppressWarnings("serial")
public class NotLL1Exception extends Exception {

	public NotLL1Exception(String message) {
		super(message);
	}
}
